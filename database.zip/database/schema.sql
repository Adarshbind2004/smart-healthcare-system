-- Simple schema for storing patients and predictions
CREATE TABLE patients (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100),
  age INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE predictions (
  id SERIAL PRIMARY KEY,
  patient_id INTEGER REFERENCES patients(id),
  prediction VARCHAR(100),
  details TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
