import React from 'react';

function App() {
  return (
    <div style={{fontFamily:'Arial, sans-serif', padding:20}}>
      <h1>Smart Healthcare System</h1>
      <p>Simple UI: Patient registration, disease prediction demo, and notifications.</p>
      <div style={{display:'flex', gap:20}}>
        <div style={{flex:1, border:'1px solid #ddd', padding:10, borderRadius:6}}>
          <h3>Register Patient</h3>
          <input placeholder="Name" style={{width:'100%', padding:8, marginBottom:8}} />
          <input placeholder="Age" style={{width:'100%', padding:8, marginBottom:8}} />
          <button style={{padding:8}}>Submit</button>
        </div>
        <div style={{flex:1, border:'1px solid #ddd', padding:10, borderRadius:6}}>
          <h3>Disease Predictor</h3>
          <p>Upload symptoms or enter comma-separated values</p>
          <input placeholder="e.g. fever,cough" style={{width:'100%', padding:8, marginBottom:8}} />
          <button style={{padding:8}}>Predict</button>
        </div>
      </div>
    </div>
  );
}

export default App;
