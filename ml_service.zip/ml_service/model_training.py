# Placeholder for training script
import pickle

def train_dummy_model():
    model = {'name':'dummy-model', 'version':1.0}
    with open('model.pkl', 'wb') as f:
        pickle.dump(model, f)
    print('Saved dummy model to model.pkl')

if __name__ == '__main__':
    train_dummy_model()
