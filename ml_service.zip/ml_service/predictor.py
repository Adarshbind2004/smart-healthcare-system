# Simple predictor that loads the dummy model and returns a fake prediction
import pickle
import json
from http.server import BaseHTTPRequestHandler, HTTPServer

MODEL_PATH = 'model.pkl'

def load_model():
    with open(MODEL_PATH, 'rb') as f:
        return pickle.load(f)

class SimpleHandler(BaseHTTPRequestHandler):
    def _set_headers(self):
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()

    def do_POST(self):
        length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(length)
        data = json.loads(body.decode('utf-8') or '{}')
        model = load_model()
        # naive rule-based response
        symptoms = data.get('symptoms', 'none')
        prediction = 'healthy' if 'fever' not in symptoms else 'needs_checkup'
        resp = {'model': model['name'], 'prediction': prediction, 'symptoms': symptoms}
        self._set_headers()
        self.wfile.write(json.dumps(resp).encode('utf-8'))

if __name__ == '__main__':
    # ensure model exists
    try:
        load_model()
    except FileNotFoundError:
        import model_training as mt; mt.train_dummy_model()
    server = HTTPServer(('0.0.0.0', 5000), SimpleHandler)
    print('ML predictor running on port 5000')
    server.serve_forever()
