const express = require('express');
const app = express();
const port = process.env.PORT || 4000;

app.use(express.json());

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'backend' });
});

app.post('/api/predict', (req, res) => {
  // Proxy to ML service in real deployment. Here we simulate a response.
  const symptoms = req.body.symptoms || 'unknown';
  res.json({ prediction: 'No serious issue detected', symptoms });
});

app.listen(port, () => console.log(`Backend running on port ${port}`));
